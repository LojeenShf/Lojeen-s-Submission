﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.DynamicData;
using System.ComponentModel.DataAnnotations;

/// <summary>
/// Summary description for Actor
/// </summary>
[MetadataType(typeof(ActorMetadata))]
public partial class Actor
{

}

public class ActorMetadata
{
    [UIHint("ActorPic")]

    public object Photo { get; set; }

}
