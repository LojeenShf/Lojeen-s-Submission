﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.DynamicData;
using System.ComponentModel.DataAnnotations;

/// <summary>
/// Summary description for Movie
/// </summary>
[MetadataType(typeof(MovieMetadata))]
public partial class Movie {
        
    }

    public class MovieMetadata
{
    [UIHint("MoviePoster")]
   
    public object Poster { get; set; }

}
