﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DynamicData_EntityTemplates_Movies : System.Web.DynamicData.EntityTemplateUserControl
{
    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand myCommand = new SqlCommand("INSERT INTO Favorite(Movie_id, User_Username) values(@id,@User)", con);
            myCommand.Parameters.AddWithValue("@id", Request.QueryString["Id"]);
            //myCommand.Parameters.AddWithValue("@User", Test1.Text);
            myCommand.Parameters.AddWithValue("@User", Page.User.Identity.Name);
            myCommand.ExecuteNonQuery();
            myCommand.Dispose();
            ImageButton1.ImageUrl = "~/DynamicData/Content/Images/Website/redheart.png";
        }
        catch (Exception)
        {
        }
        finally
        {
            con.Close();
        }
    }
}